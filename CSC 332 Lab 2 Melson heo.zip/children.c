#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/wait.h>

int main() {

    // declaring the status
    int status;

    // fork declaration
    pid_t fork1;

    // Child 1
    fork1 = fork();

    if(fork1 < 0) {
        printf("Error \n"); // Error message
    }
    else if(fork1 == 0) {
        printf("I am child one, my pid: %d\n", getpid());
        exit(0);
    }
    else {
        printf("Parent is waiting \n");
        waitpid(fork1, &status, 0);
        printf("Parent is done waiting \n");
    }


    // Child 2
    fork1 = fork();

    if (fork1 < 0 ) {
        printf("Error \n"); // Error message
        return -1;
    }
    else if (fork1 == 0) {
        printf("I am chilud two, my pid is: %d\n", getpid());
        exit(0);
    }
    else {
        printf("Parent is waiting \n");
        waitpid(fork1, &status, 0);
        printf("Parent is done waiting \n");
    }
    return 0;
}