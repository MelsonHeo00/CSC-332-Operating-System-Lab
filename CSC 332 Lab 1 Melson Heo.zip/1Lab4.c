#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>

void replacechar(char *s, char letter1, char letter2)
{
   int i = 0;

   for (i = 0; s[i]; i++) {
       if(s[i] == letter1) {
           s[i] = letter2;
        }
   }
}

int main (int argc, char* argv[]) {

    int sfd, dfd;

    // If the args do not equal to 3, this shows that there was an error in the terminal
    if (argc != 3){
        printf("\n Usage is executable sourcefile destinationfile\n");
        return 1;
    }

    errno = 0;

    // opening the two files
    sfd = open(argv[1], O_RDONLY); // read only
    dfd = open(argv[2], O_WRONLY); // write only


    if (sfd != -1) {

        // outputting that the file has opened successfully
        printf("Files open successfully");

        char *c = (char *) calloc(100, sizeof(char));
        int sz=0;

        while ((sz = read(sfd,c,100))) {
            replacechar(c,'1','L');
            write(dfd, c, sz);
            write(dfd, "XYZ", 3);
        }

        // closing both of the files
        close(sfd);
        close(dfd); 
    }

    else {

        // the file does not exist output
        if( errno == ENOENT) {
            printf("source file does not exist\n");
        }

        // the file is not accessible output
        else if( errno == EACCES) {
            printf("source file is not accessible\n");
        }
        return 1;

    }
    return 0;
}