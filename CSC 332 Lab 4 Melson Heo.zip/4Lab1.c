 #include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char* argv[]) {

    // the count arguments
    int count;

    // command arguments
    char* ArgumentCommand[1024];

    // buffer size
    char buffer[1024]; 

    // a while loop where the code will keep going unless break
    while (true) {

        // resets to 0
        count = 0;

        // command output
        printf("command: "); 

        fgets(buffer, sizeof(buffer), stdin);
        ArgumentCommand[count] = strtok(buffer, " ");
        while (ArgumentCommand[count] != NULL){
            count++;
            ArgumentCommand[count] = strtok(NULL, " ");
        }

        ArgumentCommand[count - 1][strlen(ArgumentCommand[count- 1 ]) - 1] = '\0';

        // program will end if the user inputs exit
        if (strcmp(ArgumentCommand[0], "exit") == 0){ 
            break; // breaks the while loop
        }
        
        // fork command
        int pid = fork();

        // Error handling
        if (pid == -1) {
            perror("Fork Failed.");
            exit(-1);
        }

        // Checks for invalid commands
        if (pid == 0) {
            execv(ArgumentCommand[0], ArgumentCommand);
            execvp(ArgumentCommand[0], ArgumentCommand);
            printf("Invalid Command. Please try again. \n"); // outputs if the command does not exist
            exit(0);
        }
        wait(NULL); // ends the fork process
    }

    return 0;
} 