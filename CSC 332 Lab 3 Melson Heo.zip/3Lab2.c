#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>

int main() {

  // fork declaration
  pid_t pid = fork();

  if (pid == 0) {

    // creates the child
    printf("Child created! My pid is %d\n", getpid());

    // files declaration
    char *c[] = {"ls", "-la", NULL};
    execvp(c[0], c);
  }

  // waits then exits the program
  wait(NULL);
  exit(0);
  
}