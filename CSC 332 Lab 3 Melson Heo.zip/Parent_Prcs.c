#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>

int main() {

  // fork declaration
  pid_t fork1 = fork();

  // child 1 calling
  if (fork1 == 0) {

    // child 1 PID
    printf("Child 1 pid is %d\n", getpid());
    char *p[] = {"Prcs_P1",NULL};
    execvp("./Prcs_P1",p);
  }
  
  // waiting
  wait(NULL);

  // child 2 calling
  fork1 = fork();
  if (fork1 == 0) {
    
    // child 2 PID
    printf("Child 2 pid is %d\n", getpid());
    char *p[] = {"Prcs_P2",NULL};
    execvp("./Prcs_P2",p);
  }

  // waiting and exiting
  wait(NULL);
  exit(0);
}