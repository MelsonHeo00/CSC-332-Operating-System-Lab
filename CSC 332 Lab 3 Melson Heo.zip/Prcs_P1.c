#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>

int main() {
 
    // destination 1 file creation if not created
    if (creat("destination1.txt", 0777) == -1) {
        fprintf(stderr, "Error creating file destination1.txt\n");
        return 1;
    }

    // destination 2 file creation if not created
    if (creat("destination2.txt", 0777) == -1) {
        fprintf(stderr, "Error creating file destination2.txt\n");
        return 1;
    }

    return 0;
}