#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#define BUFF_SIZE 200 // buffer size

// swaps the letters
void char_replace (char *c, char c1, char c2) {
    for(int i = 0; c[i]; ++i) {
        if (c[i] == c1) {
            c[i] = c2;
        }
    }
}

int main(int argc, char *argv[]) {

    // declaring the buff size
    char buffer[BUFF_SIZE];

    int sourcefd, destinationfd, destinationfd1;
    int s;
    errno = 0;

    // opens the source text with read only permission
    sourcefd = open("./source.txt",O_RDONLY);

    // opens the two destination files with read and write permission 
    destinationfd = open("./destination1.txt",O_RDWR, 666);
    destinationfd1 = open("./destination2.txt",O_RDWR, 666);

    // checks if the source is not already there
    if(sourcefd != -1) {
        int read1;
        int go = 0;
        int read_char = 100;

        // replacing the characters
        while (read1 = read(sourcefd, buffer, read_char)) {

            // destination 1
            if (go == 0) { 
                char_replace(buffer,'1','L'); 
                write(destinationfd,buffer,read1);
                read_char = 50; // increments of 50
                go = 1;
            }

            // destinaiton 2
            else if (go == 1) { 
                char_replace(buffer,'3','E');     
                write(destinationfd1,buffer,read1); // reads the characters
                read_char = 100; // increments of 100
                go = 0;
            }
        }

    // closes the sources files and destinaiton files
    close(sourcefd);
    close(destinationfd);
    close(destinationfd1);
    }

    return 0;
}