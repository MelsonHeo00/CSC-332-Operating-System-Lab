#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

int main (int argc, char* argv[]) {

    int fd, dfd;
    char buffer[BUFSIZ];

    // If the args do not equal to 3, this shows that there was an error in the terminal
    if (argc != 3) {
        printf("\n Usage : \n");
        return 1;
    }

    errno = 0;

    // opening the two files
    fd = open(argv[1], O_RDONLY); // first file is read only
    dfd = open(argv[2], O_RDWR | O_CREAT, 666); // second file is read, write, and create along with granted permissions

    if( fd != -1) {

            // reads the first file and writes the second file based on the first file
            write(dfd,buffer,read(fd,buffer,sizeof(buffer)));

            // closing the two files
            close(fd);
            close(dfd);
    }

    else {

        // the file does not exist output
        if(errno == ENOENT) {
            printf("File does not exist.\n");
        }

        // the file is not accessible output
        else if (errno == EACCES) {
            printf("File is not accessible\n");
            return 1;
        }
    }
    return 0;
}