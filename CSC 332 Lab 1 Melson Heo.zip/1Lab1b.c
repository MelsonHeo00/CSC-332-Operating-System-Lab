#include<stdio.h>
#include<fcntl.h>
#include<errno.h>

int main(int argc, char* argv[]) {

    int fd = open(argv[1], O_RDWR | O_CREAT, 00777 ); // this creates the file if the file does not exist

    // Error message if the file was already created
    if (fd == -1) {
        
        printf("Unable to create a file. Error Number %d\n", errno);

    }

    // File created if there is no overlap
    else {

        printf("Destination file is created \n");

    }
    return 0;
}