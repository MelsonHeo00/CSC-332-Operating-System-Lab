#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

int main (int argc, char *argv[]) {

    char *filepath = argv[1];
    int fd;
    char buffer[fd];

    // Check for file existence
    fd = access (filepath, F_OK);

    // file output if the file exists
    if (fd == 0) {
        
        printf ("\n %s exists\n", filepath);
        fd = open(filepath, O_RDONLY);
        read(fd, buffer, sizeof(buffer));
        write(fd, buffer, sizeof(buffer));
        close(fd);

        // the output of the file
        printf("%s\n", buffer);
    }

    // output if the file does not exist
    else {

        // file does not exist output
        if (errno == ENOENT) {
            printf ("%s does not exist\n", filepath);
            }

        // file is not accessible output
        else if (errno == EACCES) {
        printf ("%s is not accessible\n", filepath);
        return 0;
            }
    }

    return 0;
}