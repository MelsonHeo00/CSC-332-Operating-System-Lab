#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {

    // pipe
    int pipefd[2];
    int fork1;

    // declaring the file
    FILE *file;
    pipe(pipefd); 

    // child 1
    fork1 = fork(); 

    // Error Message
    if(fork1 == -1) {  
        printf("Error");
    }

    // Error message when the file is not existent
    if(fork1 == 0) {
        file = fopen("readme.txt", "r"); 
        if(file==NULL) {
            printf("Error opening the file");
        }
        else {
            char Line[150];
            close(pipefd[0]); 
            while(fgets(Line,sizeof(Line),file)) {
                write(pipefd[1],Line,strlen(Line));
            }
        }
        fclose(file);
    }

    // Parent will read the file 
    else {
        char buffer[150];
        file = fopen("readme.txt","a+"); 
        close(pipefd[1]); 
        char Line[150];
        int n;
        fprintf(file,"%s","Parent is waiting: ");
        while((n = read(pipefd[0],buffer,sizeof(buffer)-1))>0) {
            buffer[n] = '\0';
            fprintf(file,"%s",buffer);
        }
        close(pipefd[0]);  
        close(pipefd[1]);
        fclose(file); 
        exit(0);
    }
}