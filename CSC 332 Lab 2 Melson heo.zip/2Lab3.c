#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

// prints out the Array in a format
void printArray(int arr[],int n){
    int i;
    printf("%d",arr[0]);
    for( i = 1; i < n - 1; i++){
        printf("+%d",arr[i]);
    }
    printf("+%d",arr[n-1]);
    printf("\n");
}

// sums of the array
void sum(int arr[],int n) {
    int sum = 0 , i;
    for(i=0;i<n;i++) { 
        sum += arr[i];
    }
    printf("%d\n",sum);
}

// main function
int main(int argc, char *argv[]) {

    // if arguments are not equal to 2, then it will print out an error
    if(argc!=2){
        printf("Please Enter valid no of argument\n");
        return 0;
    }

    int n = atoi(argv[1]);

    // inputting the size
    int size1 = n/2 ,size2,size3 = n;

    // size2 condiiton
    if(n % 2  == 0) 
        size2 = n/2;
    else
        size2 = (n/2) +1;

    // creating arrays with the sizes
    int c1[size1];
    int c2[size2];
    int parent[size3];
    int i,j = 0,k = 0,m = 0;

    // Child 1
    pid_t pid = fork();
    if(pid == -1) {
        printf("fork failed.\n");
        return -1;
    }

    else if(pid == 0) {

     for(i = 2; i <= n ; i = i + 2){
     c1[j++] = i;
    }
    printf("\n Child 1 (S1) = ");
    printArray(c1,size1);
    printf(" Child 1 Sum = ");
    sum(c1,size1);
    printf("\n");
    }

    // Child 2
    else {
     pid_t pid2 = fork();
     if(pid2 == -1) {
        printf("fork failed.\n");
        return -1;
    }

    if (pid2 == 0) {

        for(i = 1; i <= n ; i = i+2)
         c2[k++] = i;
         printf("\n Child 2 (S2) = ");
         printArray(c2,size2);
         printf(" Child 2 Sum = ");
         sum(c2,size2);
         printf("\n");

    }

    else if (pid2 > 0) {

            // waits for the 2 children
            wait(NULL);
            wait(NULL); 

            // prints out the parent
            for(i=1;i<=n;i++)
            parent[m++] = i;
            printf("\n Parent (S3) = ");
            printArray(parent,size3);
            printf(" Parent Sum = ");
            sum(parent,size3);
            printf("\n");
        }
    }
}