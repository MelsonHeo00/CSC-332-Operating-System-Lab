#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>

int main() {

  // fork declaration
  pid_t pid = fork();

  if (pid == 0) {

    // child PID
    printf("Child created! My pid is %d\n", getpid());

    // date declaration
    execl("/bin/date", "date", NULL);
  }

  wait(NULL);
  exit(0);
}